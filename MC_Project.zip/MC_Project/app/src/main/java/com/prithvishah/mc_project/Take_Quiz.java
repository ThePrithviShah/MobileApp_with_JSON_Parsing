package com.prithvishah.mc_project;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.File;
import java.io.FileInputStream;

public class Take_Quiz extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_take__quiz);

        File path = this.getExternalFilesDir(null);
        StringBuilder sb = new StringBuilder();
        File file = new File(path, "file_Y.json");
        int length = (int) file.length();
        byte[] bytes = new byte[length];
        try {
            FileInputStream in = new FileInputStream(file);

            try {
                in.read(bytes);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }catch(Exception f){
            f.printStackTrace();
        }
        try {
            String contents = new String(bytes);
            String con=contents+"]";
            // Toast.makeText(getApplicationContext(), con, Toast.LENGTH_SHORT).show();


            JSONArray jArray = new JSONArray(con);

            LinearLayout layout = findViewById(R.id.layout);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );

            for (int i = 0; i < jArray.length(); ++i) {
                String ques = jArray.getJSONObject(i).getString("Question");
                String o1 = jArray.getJSONObject(i).getString("Option1");
                String o2 = jArray.getJSONObject(i).getString("Option2");
                String o3 = jArray.getJSONObject(i).getString("Option3");
                String o4 = jArray.getJSONObject(i).getString("Option4");
                //Toast.makeText(getApplicationContext(), o3, Toast.LENGTH_SHORT).show();


                TextView textView = new TextView(this);
                textView.setText(ques);

                RadioGroup radioGroup = new RadioGroup(this);


                RadioButton radioButtonView = new RadioButton(this);
                radioButtonView.setText(o1);

                RadioButton radioButtonView2 = new RadioButton(this);
                radioButtonView2.setText(o2);

                RadioButton radioButtonView3 = new RadioButton(this);
                radioButtonView3.setText(o3);

                RadioButton radioButtonView4 = new RadioButton(this);
                radioButtonView4.setText(o4);

                layout.addView(textView, p);
                layout.addView(radioGroup, p);
                radioGroup.addView(radioButtonView, p);
                radioGroup.addView(radioButtonView2, p);
                radioGroup.addView(radioButtonView3, p);
                radioGroup.addView(radioButtonView4, p);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }catch(Exception f){
            f.printStackTrace();
        }
    }
}
