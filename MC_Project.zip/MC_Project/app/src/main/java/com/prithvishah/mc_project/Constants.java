package com.prithvishah.mc_project;
public class Constants {
    private static final String ROOT_URL="http://192.168.0.179/Android/v1/";

    public static final String URL_REGISTER=ROOT_URL+"registerUsers.php";
    public static final String URL_LOGIN=ROOT_URL+"userLogin.php";
}
