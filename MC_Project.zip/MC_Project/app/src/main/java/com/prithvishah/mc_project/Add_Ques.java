package com.prithvishah.mc_project;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Add_Ques extends AppCompatActivity {
    JSONObject jsonObject=new JSONObject();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add__ques);
    }
    public void submit(View view){
        EditText t1,t2,t3,t4,t5;
        t1=findViewById(R.id.question);
        t2=findViewById(R.id.option1);
        t3=findViewById(R.id.option2);
        t4=findViewById(R.id.option3);
        t5=findViewById(R.id.option4);
        String ques=t1.getText().toString();
        String o1=t2.getText().toString();
        String o2=t3.getText().toString();
        String o3=t4.getText().toString();
        String ca=t5.getText().toString();
        try{
            //JSONObject jsonObject=new JSONObject();
            jsonObject.put("Question",ques);
            jsonObject.put("Option1",o1);
            jsonObject.put("Option2",o2);
            jsonObject.put("Option3",o3);
            jsonObject.put("Option4",ca);
            //Toast.makeText(getApplicationContext(), jsonObject.toString(), Toast.LENGTH_SHORT).show();

            /*String filename = "JSON_File";
            String fileContents = jsonObject.toString();
            FileOutputStream outputStream;

            try {
                outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                outputStream.write(fileContents.getBytes());
                outputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }*/

           /* try {
                new File("D:"  ).mkdir();
                File file = new File("D:\\sample.txt");
                if (!file.exists()) {
                    file.createNewFile();
                }
                FileOutputStream fileOutputStream = new FileOutputStream(file,true);
                fileOutputStream.write((jsonObject.toString() + System.getProperty("line.separator")).getBytes());

            }  catch(FileNotFoundException ex) {
                ex.printStackTrace();
            }  catch(IOException ex) {
                ex.printStackTrace();
            }*/

           /*FileWriter fileWriter = new FileWriter("C:\\sample.txt");

          // Writing the jsonObject into sample.json
             fileWriter.write(jsonObject.toString());
             fileWriter.close();*/
            File path = this.getExternalFilesDir(null);
            File file = new File(path, "file_Y.json");
            //int length = (int) file.length();
            FileOutputStream stream = new FileOutputStream(file,true);

            try {
                //stream.write("[".getBytes());
                stream.write(",".getBytes());
                stream.write(jsonObject.toString().getBytes());
            } finally {
                stream.close();
            }

            int length = (int) file.length();

            byte[] bytes = new byte[length];

            FileInputStream in = new FileInputStream(file);
            try {
                in.read(bytes);
            } finally {
                in.close();
            }
            String contents = new String(bytes);

        }catch(JSONException e){
            e.printStackTrace();
        }catch(Exception e){
            e.getStackTrace();
        }

        Intent i=new Intent(getApplicationContext(),MainAct2.class);
        startActivity(i);
    }
}
