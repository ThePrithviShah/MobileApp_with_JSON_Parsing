package com.prithvishah.mc_project;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActvity extends AppCompatActivity implements View.OnClickListener{

        private EditText editTextUsername, editTextemail,editTextPassword;
        private Button buttonLogin;
        private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_actvity);

        editTextUsername=findViewById(R.id.editTextUsername);
        editTextPassword=findViewById(R.id.editTextPassword);

        buttonLogin=findViewById(R.id.buttonLogin);

        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Please Wait..");

        buttonLogin.setOnClickListener(this);

    }

    private void userLogin(){
        final String username=editTextUsername.getText().toString().trim();
        final String password=editTextPassword.getText().toString().trim();

        StringRequest stringRequest=new StringRequest(Request.Method.POST, Constants.URL_LOGIN, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();

                try {
                    JSONObject obj=new JSONObject(response);
                    if(!obj.getBoolean("error")){
                        sharedPrefManager.getInstance(getApplicationContext()).userLogin(obj.getInt("id"),obj.getString("username"),obj.getString("email"));
                        Toast.makeText(getApplicationContext(),"User login Successful",Toast.LENGTH_LONG).show();
                        Intent i=new Intent(getApplicationContext(),MainAct2.class);
                        startActivity(i);
                    }else{
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap<>();
                params.put("username",username);
                params.put("password",password);
                return params;

            }
        };

        RequestHandler.getInstance(this).addToRequestQueue(stringRequest);
    }

    @Override
    public void onClick(View v) {
        if(v==buttonLogin){
            userLogin();
        }
    }
}
